# Step 1: Enable script execution
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force

# Step 2: Expand the %userprofile% environment variable and store it in a variable
$userProfile = $env:userprofile

# Step 3: Define the directory and target files
$scikitplotDir = Join-Path -Path $userProfile -ChildPath "anaconda3\Lib\site-packages\scikitplot"
$files = @("plotters.py", "metrics.py")

# Step 4: Iterate through the files and replace the string
foreach ($file in $files) {
    $filePath = Join-Path -Path $scikitplotDir -ChildPath $file
    if (Test-Path $filePath) {
        # Get content, replace text, and write back to file
        (Get-Content -Path $filePath) -replace "from scipy import interp", "interp = np.interp" | Set-Content -Path $filePath
        Write-Host "Updated: $filePath"
    } else {
        Write-Host "File not found: $filePath"
    }
}

Write-Host "Script completed."
